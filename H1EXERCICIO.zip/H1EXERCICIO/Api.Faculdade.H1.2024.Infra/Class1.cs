﻿namespace Api.Faculdade.H1._2024.Infra
{
    public class Class1
    {

    }
}
