﻿namespace Api.Faculdade.H1._2024.Utilitarios
{
    public class Class1
    {

    }
}
